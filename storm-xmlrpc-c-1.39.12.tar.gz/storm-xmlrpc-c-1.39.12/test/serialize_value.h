#ifndef SERIALIZE_VALUE_H_INCLUDED
#define SERIALIZE_VALUE_H_INCLUDED

void 
test_serialize_value(void);

#endif
