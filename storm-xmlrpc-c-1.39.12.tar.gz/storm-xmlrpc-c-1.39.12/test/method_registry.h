#ifndef TEST_METHOD_REGISTRY_H_INCLUDED
#define TEST_METHOD_REGISTRY_H_INCLUDED

void
test_method_registry(void);

#endif
